/*//PESQUISA

// Obtém referências aos elementos HTML
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const searchResults = document.getElementById('searchResults');

// Adiciona um ouvinte de eventos para o botão de pesquisa
searchButton.addEventListener('click', () => {
    // Obtém o valor do campo de entrada
    const query = searchInput.value.trim();

    // Limpa os resultados anteriores
    searchResults.innerHTML = '';

    // Verifica se o campo de pesquisa não está vazio
    if (query) {
        // Simula uma pesquisa mostrando o texto pesquisado
        searchResults.innerHTML = `<p>Você pesquisou por: <strong>${query}</strong></p>`;
    } else {
        searchResults.innerHTML = '<p>Por favor, insira um termo de pesquisa.</p>';
    }
});

// Opcional: permite enviar a pesquisa pressionando Enter
searchInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        searchButton.click();
    }
});*/

/*ANOTAÇÃO*/

// script.js
/*document.addEventListener('DOMContentLoaded', () => {
    const noteInput = document.getElementById('noteInput');
    const addNoteBtn = document.getElementById('addNoteBtn');
    const notesContainer = document.getElementById('notesContainer');

    // Função para criar uma nova nota
    function createNoteElement(text) {
        const noteElement = document.createElement('div');
        noteElement.classList.add('note');
        noteElement.innerHTML = `
            <span>${text}</span>
            <button class="delete-btn">X</button>
        `;
        return noteElement;
    }

    // Função para adicionar uma nova nota
    function addNote() {
        const text = noteInput.value.trim();
        if (text) {
            const noteElement = createNoteElement(text);
            notesContainer.appendChild(noteElement);
            noteInput.value = '';
        }
    }

    // Adiciona uma nota ao clicar no botão
    addNoteBtn.addEventListener('click', addNote);

    // Adiciona uma nota ao pressionar Enter
    noteInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            addNote();
        }
    });

    // Remove a nota ao clicar no botão de excluir
    notesContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('delete-btn')) {
            event.target.parentElement.remove();
        }
    });
});*/

//Teste calendario

/*document.addEventListener('DOMContentLoaded', function() {
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const monthYearElement = document.getElementById('month-year');
    const daysElement = document.getElementById('days');
    
    let currentDate = new Date();

    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();

        // Set month and year in header
        monthYearElement.textContent = `${date.toLocaleString('pt-BR', { month: 'long' })} ${year}`;

        // Clear previous days
        daysElement.innerHTML = '';

        // Get the first day of the month and the number of days in the month
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        // Get the day of the week for the first day
        const startDay = firstDay.getDay();
        const totalDays = lastDay.getDate();

        // Create empty days for alignment
        for (let i = 0; i < startDay; i++) {
            const emptyDiv = document.createElement('div');
            daysElement.appendChild(emptyDiv);
        }

        // Create days of the month
        for (let day = 1; day <= totalDays; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = day;
            daysElement.appendChild(dayDiv);
        }
    }

    // Event listeners for navigation buttons
    prevMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    // Initial render
    renderCalendar(currentDate);
});*/


/*document.addEventListener('DOMContentLoaded', function() {
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const monthYearElement = document.getElementById('month-year');
    const daysElement = document.getElementById('days');
    const modal = document.getElementById('appointment-modal');
    const closeModalButton = document.querySelector('.modal .close');
    const saveButton = document.getElementById('save-appointment');
    const modalDateInput = document.getElementById('modal-date');
    const modalTextArea = document.getElementById('modal-text');
    
    let currentDate = new Date();
    let appointments = {};

    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();

        // Set month and year in header
        monthYearElement.textContent = `${date.toLocaleString('pt-BR', { month: 'long' })} ${year}`;

        // Clear previous days
        daysElement.innerHTML = '';

        // Get the first day of the month and the number of days in the month
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        // Get the day of the week for the first day
        const startDay = firstDay.getDay();
        const totalDays = lastDay.getDate();

        // Create empty days for alignment
        for (let i = 0; i < startDay; i++) {
            const emptyDiv = document.createElement('div');
            daysElement.appendChild(emptyDiv);
        }

        // Create days of the month
        for (let day = 1; day <= totalDays; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = day;

            // Add appointment indicator if needed
            if (appointments[`${year}-${month + 1}-${day}`]) {
                const appointmentIndicator = document.createElement('div');
                appointmentIndicator.className = 'appointment';
                appointmentIndicator.textContent = appointments[`${year}-${month + 1}-${day}`].length;
                dayDiv.appendChild(appointmentIndicator);
            }

            // Add click event for adding/editing appointments
            dayDiv.addEventListener('click', function() {
                const dateString = `${year}-${month + 1}-${day}`;
                modalDateInput.value = dateString;
                modalDateInput.disabled = true;
                modalTextArea.value = appointments[dateString] ? appointments[dateString].join('\n') : '';
                modal.style.display = 'block';
            });

            daysElement.appendChild(dayDiv);
        }
    }

    // Event listeners for navigation buttons
    prevMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    // Save appointment to the day
    saveButton.addEventListener('click', function() {
        const dateString = modalDateInput.value;
        const text = modalTextArea.value.trim();
        if (text) {
            appointments[dateString] = text.split('\n');
        } else {
            delete appointments[dateString];
        }
        modal.style.display = 'none';
        renderCalendar(currentDate);
    });

    // Close modal
    closeModalButton.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Initial render
    renderCalendar(currentDate);
});*/



/*document.addEventListener('DOMContentLoaded', function() {
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const monthYearElement = document.getElementById('month-year');
    const daysElement = document.getElementById('days');
    const modal = document.getElementById('appointment-modal');
    const closeModalButton = document.querySelector('.modal .close');
    const saveButton = document.getElementById('save-appointment');
    const modalDateInput = document.getElementById('modal-date');
    const modalTextArea = document.getElementById('modal-text');
    
    let currentDate = new Date();
    let appointments = JSON.parse(localStorage.getItem('appointments')) || {};

    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();

        // Set month and year in header
        monthYearElement.textContent = `${date.toLocaleString('pt-BR', { month: 'long' })} ${year}`;

        // Clear previous days
        daysElement.innerHTML = '';

        // Get the first day of the month and the number of days in the month
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        // Get the day of the week for the first day
        const startDay = firstDay.getDay();
        const totalDays = lastDay.getDate();

        // Create empty days for alignment
        for (let i = 0; i < startDay; i++) {
            const emptyDiv = document.createElement('div');
            daysElement.appendChild(emptyDiv);
        }

        // Create days of the month
        for (let day = 1; day <= totalDays; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = day;

            // Add appointment indicator if needed
            const dateString = `${year}-${month + 1}-${day}`;
            if (appointments[dateString]) {
                const appointmentIndicator = document.createElement('div');
                appointmentIndicator.className = 'appointment';
                appointmentIndicator.textContent = appointments[dateString].length;
                dayDiv.appendChild(appointmentIndicator);
            }

            // Add click event for adding/editing appointments
            dayDiv.addEventListener('click', function() {
                modalDateInput.value = dateString;
                modalDateInput.disabled = true;
                modalTextArea.value = appointments[dateString] ? appointments[dateString].join('\n') : '';
                modal.style.display = 'block';
            });

            daysElement.appendChild(dayDiv);
        }
    }

    // Event listeners for navigation buttons
    prevMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    // Save appointment to the day
    saveButton.addEventListener('click', function() {
        const dateString = modalDateInput.value;
        const text = modalTextArea.value.trim();
        if (text) {
            appointments[dateString] = text.split('\n');
        } else {
            delete appointments[dateString];
        }
        localStorage.setItem('appointments', JSON.stringify(appointments));
        modal.style.display = 'none';
        renderCalendar(currentDate);
    });

    // Close modal
    closeModalButton.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Initial render
    renderCalendar(currentDate);
});*/








/*document.addEventListener('DOMContentLoaded', function() {
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const monthYearElement = document.getElementById('month-year');
    const daysElement = document.getElementById('days');
    const noteModal = document.getElementById('note-modal');
    const closeModalButton = document.querySelector('.modal .close');
    const saveNoteButton = document.getElementById('save-note');
    const modalDateInput = document.getElementById('modal-date');
    const modalTextArea = document.getElementById('modal-text');

    let currentDate = new Date();
    let notes = JSON.parse(localStorage.getItem('notes')) || {};

    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();

        // Set month and year in header
        monthYearElement.textContent = `${date.toLocaleString('pt-BR', { month: 'long' })} ${year}`;

        // Clear previous days
        daysElement.innerHTML = '';

        // Get the first day of the month and the number of days in the month
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        // Get the day of the week for the first day
        const startDay = firstDay.getDay();
        const totalDays = lastDay.getDate();

        // Create empty days for alignment
        for (let i = 0; i < startDay; i++) {
            const emptyDiv = document.createElement('div');
            daysElement.appendChild(emptyDiv);
        }

        // Create days of the month
        for (let day = 1; day <= totalDays; day++) {
            const dayDiv = document.createElement('div');
            dayDiv.textContent = day;

            // Add note if needed
            const dateString = `${year}-${month + 1}-${day}`;
            if (notes[dateString]) {
                const noteDiv = document.createElement('div');
                noteDiv.className = 'note';
                noteDiv.textContent = notes[dateString];
                dayDiv.appendChild(noteDiv);
            }

            // Add click event for adding/editing notes
            dayDiv.addEventListener('click', function() {
                modalDateInput.value = dateString;
                modalTextArea.value = notes[dateString] || '';
                noteModal.style.display = 'block';
            });

            daysElement.appendChild(dayDiv);
        }
    }

    // Event listeners for navigation buttons
    prevMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    // Save note to the day
    saveNoteButton.addEventListener('click', function() {
        const dateString = modalDateInput.value;
        const text = modalTextArea.value.trim();
        if (text) {
            notes[dateString] = text;
        } else {
            delete notes[dateString];
        }
        localStorage.setItem('notes', JSON.stringify(notes));
        noteModal.style.display = 'none';
        renderCalendar(currentDate);
    });

    // Close modal
    closeModalButton.addEventListener('click', function() {
        noteModal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === noteModal) {
            noteModal.style.display = 'none';
        }
    });

    // Initial render
    renderCalendar(currentDate);
});*/





/*document.addEventListener('DOMContentLoaded', () => {
    const calendarElement = document.getElementById('calendar');
    const noteDateElement = document.getElementById('noteDate');
    const noteTextElement = document.getElementById('noteText');
    const addNoteBtn = document.getElementById('addNoteBtn');
    const notesList = document.getElementById('notesList');

    // Função para criar um calendário simples
    function generateCalendar() {
        const date = new Date();
        const year = date.getFullYear();
        const month = date.getMonth();

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        let calendarHTML = '<table><thead><tr>';
        const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        daysOfWeek.forEach(day => {
            calendarHTML += `<th>${day}</th>`;
        });
        calendarHTML += '</tr></thead><tbody><tr>';

        // Preencher os dias antes do início do mês
        for (let i = 0; i < firstDay; i++) {
            calendarHTML += '<td></td>';
        }

        // Preencher os dias do mês
        for (let day = 1; day <= daysInMonth; day++) {
            calendarHTML += `<td>${day}</td>`;
            if ((day + firstDay) % 7 === 0) {
                calendarHTML += '</tr><tr>';
            }
        }

        // Completar a última linha se necessário
        if ((daysInMonth + firstDay) % 7 !== 0) {
            for (let i = (daysInMonth + firstDay) % 7; i < 7; i++) {
                calendarHTML += '<td></td>';
            }
        }

        calendarHTML += '</tr></tbody></table>';
        calendarElement.innerHTML = calendarHTML;
    }

    // Função para adicionar nota
    function addNote() {
        const date = noteDateElement.value;
        const text = noteTextElement.value;
        if (date && text) {
            const noteItem = document.createElement('li');
            noteItem.textContent = `${date}: ${text}`;
            notesList.appendChild(noteItem);
            noteDateElement.value = '';
            noteTextElement.value = '';
        } else {
            alert('Por favor, preencha a data e a nota.');
        }
    }

    addNoteBtn.addEventListener('click', addNote);

    generateCalendar();
});*/



//FALTAS

/*document.addEventListener("DOMContentLoaded", function() {
    const daysInMonth = 30;
    const firstDayOfMonth = new Date(2024, 8, 1).getDay(); // Setembro é o mês 8 no JavaScript (base 0)
    const calendar = document.getElementById('calendar');

    // Criar cabeçalhos dos dias da semana
    const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    daysOfWeek.forEach(day => {
        const header = document.createElement('div');
        header.className = 'day';
        header.textContent = day;
        calendar.appendChild(header);
    });

    // Criar os dias do mês
    for (let i = 0; i < firstDayOfMonth; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'day';
        calendar.appendChild(emptyCell);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'day';
        dayCell.textContent = day;
        dayCell.dataset.day = day;

        // Marcar alguns dias como faltas (exemplo)
        const absentDays = [1, 5, 7, 15];
        if (absentDays.includes(day)) {
            dayCell.classList.add('faltou');
        }

        // Adicionar evento de clique para marcar/desmarcar falta
        dayCell.addEventListener('click', function() {
            this.classList.toggle('faltou');
        });

        calendar.appendChild(dayCell);
    }
});*/


document.addEventListener("DOMContentLoaded", function() {
    const yearSelect = document.getElementById('year');
    const monthSelect = document.getElementById('month');
    const calendar = document.getElementById('calendar');

    // Preencher seletores de ano e mês
    for (let year = 2020; year <= 2030; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }

    for (let month = 0; month < 12; month++) {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = new Date(2024, month).toLocaleString('pt-BR', { month: 'long' });
        monthSelect.appendChild(option);
    }

    // Função para criar o calendário
    function renderCalendar(year, month) {
        calendar.innerHTML = '';

        // Criar cabeçalhos dos dias da semana
        const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        daysOfWeek.forEach(day => {
            const header = document.createElement('div');
            header.className = 'header';
            header.textContent = day;
            calendar.appendChild(header);
        });

        // Primeira data do mês
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const lastDate = lastDay.getDate();
        const firstDayOfWeek = firstDay.getDay();

        // Criar células vazias para os dias antes do primeiro dia do mês
        for (let i = 0; i < firstDayOfWeek; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'day';
            calendar.appendChild(emptyCell);
        }

        // Criar células para os dias do mês
        for (let day = 1; day <= lastDate; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'day';
            dayCell.textContent = day;
            dayCell.dataset.day = day;

            // Marcar dias como faltas (exemplo)
            const absentDays = JSON.parse(localStorage.getItem('absentDays')) || [];
            if (absentDays.includes(day)) {
                dayCell.classList.add('faltou');
            }

            // Adicionar evento de clique para marcar/desmarcar falta
            dayCell.addEventListener('click', function() {
                this.classList.toggle('faltou');
                updateAbsentDays(year, month, this.dataset.day, this.classList.contains('faltou'));
            });

            calendar.appendChild(dayCell);
        }
    }

    // Função para atualizar as faltas no armazenamento local
    function updateAbsentDays(year, month, day, isAbsent) {
        let absentDays = JSON.parse(localStorage.getItem('absentDays')) || [];
        const dateStr = `${year}-${month}-${day}`;

        if (isAbsent) {
            absentDays.push(dateStr);
        } else {
            absentDays = absentDays.filter(date => date !== dateStr);
        }

        localStorage.setItem('absentDays', JSON.stringify(absentDays));
    }

    // Inicializar o calendário com o ano e mês atuais
    const now = new Date();
    yearSelect.value = now.getFullYear();
    monthSelect.value = now.getMonth();
    renderCalendar(now.getFullYear(), now.getMonth());

    // Atualizar o calendário quando o ano ou mês mudar
    yearSelect.addEventListener('change', () => {
        renderCalendar(yearSelect.value, monthSelect.value);
    });
    monthSelect.addEventListener('change', () => {
        renderCalendar(yearSelect.value, monthSelect.value);
    });
});



