//Página do calendário escolar

document.addEventListener('DOMContentLoaded', () => {
    const noteDateElement = document.getElementById('noteDate');
    const noteTextElement = document.getElementById('noteText');
    const addNoteBtn = document.getElementById('addNoteBtn');
    const notesList = document.getElementById('notesList');

   
    // Função para adicionar nota
    function addNote() {
        const date = noteDateElement.value;
        const text = noteTextElement.value;
        if (date && text) {
            const noteItem = document.createElement('li');
            noteItem.textContent = `${date}: ${text}`;
            notesList.appendChild(noteItem);
            noteDateElement.value = '';
            noteTextElement.value = '';
        } else {
            alert('Por favor, preencha a data e a nota.');
        }
    }

    addNoteBtn.addEventListener('click', addNote);

    generateCalendario();
});

// calendario

document.addEventListener('DOMContentLoaded', () => {
    const mesAnteriorButton = document.getElementById('mesAnterior');
    const proximoMesButton = document.getElementById('proximoMes');
    const mesAnoDisplay = document.getElementById('mesAno');
    const calendarBody = document.getElementById('calendarBody');

    let currentDate = new Date();

    function renderCalendar(date) {
        calendarBody.innerHTML = '';

        const year = date.getFullYear();
        const month = date.getMonth();

        const firstDayOfMonth = new Date(year, month, 1);
        const lastDayOfMonth = new Date(year, month + 1, 0);
        const startDay = firstDayOfMonth.getDay();
        const endDate = lastDayOfMonth.getDate();

    
        mesAnoDisplay.textContent = `${date.toLocaleString('pt-BR', { month: 'long' })} ${year}`;

        let day = 1;
        for (let i = 0; i < 6; i++) { 
            const row = document.createElement('tr');
            for (let j = 0; j < 7; j++) { 
                const cell = document.createElement('td');
                if (i === 0 && j < startDay) {
                    cell.textContent = '';
                } else if (day > endDate) {
                    cell.textContent = '';
                } else {
                    cell.textContent = day;
                    day++;
                }
                row.appendChild(cell);
            }
            calendarBody.appendChild(row);
        }
    }

    function changeMonth(offset) {
        currentDate.setMonth(currentDate.getMonth() + offset);
        renderCalendar(currentDate);
    }

    mesAnteriorButton.addEventListener('click', () => changeMonth(-1));
    proximoMesButton.addEventListener('click', () => changeMonth(1));

    renderCalendar(currentDate);
});

//CONTROLE DE FALTAS

document.addEventListener("DOMContentLoaded", function() {
    const yearSelect = document.getElementById('year');
    const monthSelect = document.getElementById('month');
    const calendar = document.getElementById('calendario_faltas');

    // Preencher seletores de ano e mês
    for (let year = 2020; year <= 2030; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }

    for (let month = 0; month < 12; month++) {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = new Date(2024, month).toLocaleString('pt-BR', { month: 'long' });
        monthSelect.appendChild(option);
    }

    // Função para criar o calendário
    function renderCalendar(year, month) {
        calendar.innerHTML = '';

        // Criar cabeçalhos dos dias da semana
        const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        daysOfWeek.forEach(day => {
            const header = document.createElement('div');
            header.className = 'header';
            header.textContent = day;
            calendar.appendChild(header);
        });

        // Primeira data do mês
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const lastDate = lastDay.getDate();
        const firstDayOfWeek = firstDay.getDay();

        // Criar células vazias para os dias antes do primeiro dia do mês
        for (let i = 0; i < firstDayOfWeek; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'day';
            calendar.appendChild(emptyCell);
        }

        // Criar células para os dias do mês
        for (let day = 1; day <= lastDate; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'day';
            dayCell.textContent = day;
            dayCell.dataset.day = day;

            // Marcar dias como faltas (exemplo)
            const absentDays = JSON.parse(localStorage.getItem('absentDays')) || [];
            if (absentDays.includes(day)) {
                dayCell.classList.add('faltou');
            }

            // Adicionar evento de clique para marcar/desmarcar falta
            dayCell.addEventListener('click', function() {
                this.classList.toggle('faltou');
                updateAbsentDays(year, month, this.dataset.day, this.classList.contains('faltou'));
            });

            calendar.appendChild(dayCell);
        }
    }

    // Função para atualizar as faltas no armazenamento local
    function updateAbsentDays(year, month, day, isAbsent) {
        let absentDays = JSON.parse(localStorage.getItem('absentDays')) || [];
        const dateStr = `${year}-${month}-${day}`;

        if (isAbsent) {
            absentDays.push(dateStr);
        } else {
            absentDays = absentDays.filter(date => date !== dateStr);
        }

        localStorage.setItem('absentDays', JSON.stringify(absentDays));
    }

    // Inicializar o calendário com o ano e mês atuais
    const now = new Date();
    yearSelect.value = now.getFullYear();
    monthSelect.value = now.getMonth();
    renderCalendar(now.getFullYear(), now.getMonth());

    // Atualizar o calendário quando o ano ou mês mudar
    yearSelect.addEventListener('change', () => {
        renderCalendar(yearSelect.value, monthSelect.value);
    });
    monthSelect.addEventListener('change', () => {
        renderCalendar(yearSelect.value, monthSelect.value);
    });
});




